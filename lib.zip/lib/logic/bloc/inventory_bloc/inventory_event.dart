import 'package:fotocopy_app/data/models/inventory_model.dart';

abstract class InventoryEvent {}

class WatchInventoryStarted extends InventoryEvent {}

class InventoryUpdated extends InventoryEvent {
  final List<InventoryModel> items;
  InventoryUpdated(this.items);
}

class UpdateStokRequested extends InventoryEvent {
  final String id;
  final int jumlahBaru;
  UpdateStokRequested(this.id, this.jumlahBaru);
}

class ClearInventoryData extends InventoryEvent {}

class LoadInventory extends InventoryEvent {}

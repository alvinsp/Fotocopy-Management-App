import 'dart:async';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fotocopy_app/data/models/oder_model.dart';
import 'package:fotocopy_app/data/repositories/oder_repository.dart';
import 'package:fotocopy_app/logic/bloc/transaction_bloc/transaction_event.dart';
import 'package:fotocopy_app/logic/bloc/transaction_bloc/transaction_state.dart';

class TransactionBloc extends Bloc<TransactionEvent, TransactionState> {
  final OrderRepository _repository;
  StreamSubscription? _subscription;
  StreamSubscription? _orderSubscription;
  final DateTime _currentDate = DateTime.now();
  String _currentSearch = '';
  List<OrderModel> _allOrders = [];

  TransactionBloc(this._repository) : super(TransactionInitial()) {
    // 1. Update List Data (Penerima utama dari Firestore)
    on<UpdateTransactionList>((event, emit) {
      _allOrders =
          event.orders; // Simpan ke variabel lokal agar Search bisa pakai

      // Filter berdasarkan search query yang sedang aktif
      final filtered = _allOrders.where((order) {
        return order.namaPelanggan
            .toLowerCase()
            .contains(_currentSearch.toLowerCase());
      }).toList();

      emit(TransactionLoaded(
        filtered,
        _currentDate, // Gunakan variabel _currentDate milik Bloc
        searchQuery: _currentSearch,
      ));
    });

// 2. Perbaiki Search agar tidak "lupa" data
    on<SearchNameRequested>((event, emit) {
      _currentSearch = event.query; // Update query global di Bloc

      final filtered = _allOrders.where((order) {
        return order.namaPelanggan
            .toLowerCase()
            .contains(_currentSearch.toLowerCase());
      }).toList();

      emit(TransactionLoaded(filtered, _currentDate,
          searchQuery: _currentSearch));
    });

// 3. Clear Data (Pastikan semua null)
    on<ClearTransactionData>((event, emit) async {
      await _subscription?.cancel();
      await _orderSubscription?.cancel();
      _subscription = null;
      _orderSubscription = null;
      _allOrders = []; // Kosongkan list
      _currentSearch = ''; // Reset search
      emit(TransactionInitial());
    });
  }

  @override
  Future<void> close() {
    _subscription?.cancel();
    _orderSubscription?.cancel();
    return super.close();
  }
}
